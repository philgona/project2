# Independent Project

## Instructions
  1) Please fork the Moringa School **mpft1-ip** repo to your own account.

  2) Clone **your forked repo** to your own machine.`

  3) Fill in the form under the [IP submission](http://moringaprep-ft.herokuapp.com/#10.html) heading in the LMS

  4) Complete the independent project.
  
  5) Push your commits up to your forked repo.
